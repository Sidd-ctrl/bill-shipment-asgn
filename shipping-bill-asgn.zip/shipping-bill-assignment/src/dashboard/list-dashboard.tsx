import { routes } from '@/shared/route-paths'
import { invoiceTotal, SavedBill } from '@/shipping-bills/model'
import { shippingBillService } from '@/shipping-bills/shipping-bill-service'
import { navigate } from 'core/routing'
import { toast } from 'core/toast-manager'
import { useCallback, useEffect, useState } from 'react'
import { Badge } from 'ui/basic/badge'
import { Button } from 'ui/basic/button'
import { Card, CardContent } from 'ui/basic/card'
import { Table } from 'ui/basic/table'
import { Input } from 'ui/inputs/input'

export default function ListDashboard() {
  const [bills, setBills] = useState<SavedBill[]>([])
  const [search, setSearch] = useState('')
  const [isLoading, setIsLoading] = useState(true)
  const [loadError, setLoadError] = useState('')
  const [downloadingId, setDownloadingId] = useState<number | null>(null)

  const fetchBills = useCallback(async () => {
    setIsLoading(true)
    setLoadError('')
    try {
      const loadedBills = await shippingBillService.list()
      setBills(loadedBills)
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : 'Shipping bills could not be loaded.')
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    void fetchBills()
  }, [fetchBills])

  async function handleDownloadFlatFile(bill: SavedBill) {
    setDownloadingId(bill.id)
    try {
      await shippingBillService.downloadFlatFile(bill.id, bill)
      toast.success(`Flat file (.sb) downloaded for #${bill.values.jobNumber ?? bill.id}`)
    } catch {
      toast.error('Failed to generate flat file')
    } finally {
      setDownloadingId(null)
    }
  }

  const normalizedSearch = search.trim().toLowerCase()
  const filtered = bills
    .filter((bill) => {
      if (!normalizedSearch) return true
      const haystack = [
        bill.id,
        bill.values.jobNumber ?? '',
        bill.values.exporterName ?? '',
        bill.values.consigneeName ?? '',
        ...bill.values.invoices.map((invoice) => invoice.invoiceNumber)
      ]
        .join(' ')
        .toLowerCase()
      return haystack.includes(normalizedSearch)
    })
    .sort((first, second) => new Date(second.updated).getTime() - new Date(first.updated).getTime())

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-gray-950">Shipping bills</h1>
          <p className="mt-1 text-sm text-gray-500">Create and continue the shipping bill step of each export job.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => void fetchBills()} disabled={isLoading}>
            {isLoading ? 'Loading...' : 'Refresh'}
          </Button>
          <Button onClick={() => navigate(routes.shippingBillNew)}>+ New shipping bill</Button>
        </div>
      </div>

      <Card>
        <CardContent className="space-y-4 pt-6">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div className="w-full max-w-sm">
              <Input
                label="Search bills"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Job, invoice, exporter or consignee"
              />
            </div>
            <span className="text-sm text-gray-500" aria-live="polite">
              {isLoading ? 'Loading...' : `${filtered.length} ${filtered.length === 1 ? 'bill' : 'bills'}`}
            </span>
          </div>

          {loadError && (
            <div role="alert" className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-800">
              <p className="font-medium">Shipping bills could not be loaded</p>
              <p className="mt-1">{loadError}</p>
              <Button className="mt-3" size="sm" variant="outline" onClick={() => void fetchBills()}>
                Try again
              </Button>
            </div>
          )}

          {!loadError && isLoading && (
            <div className="rounded-lg border border-dashed border-gray-300 p-10 text-center" aria-busy="true">
              <p className="font-medium">Loading shipping bills...</p>
              <p className="mt-1 text-sm text-gray-500">Fetching the latest saved bills.</p>
            </div>
          )}

          {!loadError && !isLoading && filtered.length > 0 && (
            <div className="overflow-x-auto">
              <Table>
                <thead>
                  <tr>
                    <th>Job</th>
                    <th>Exporter to Consignee</th>
                    <th>Route</th>
                    <th>Invoices</th>
                    <th>Status</th>
                    <th>Updated</th>
                    <th className="text-right">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((bill) => {
                    const total = bill.values.invoices.reduce((sum, invoice) => sum + invoiceTotal(invoice), 0)
                    const updatedDate = new Date(bill.updated)
                    return (
                      <tr key={bill.id}>
                        <td className="font-medium">
                          {bill.values.jobNumber ? `#${bill.values.jobNumber}` : `Bill #${bill.id}`}
                          <span className="block text-xs font-normal text-gray-500">{bill.values.jobDate}</span>
                        </td>
                        <td>
                          {bill.values.exporterName ?? 'Exporter not recorded'}
                          <span className="block text-xs text-gray-500">
                            to {bill.values.consigneeName ?? 'Consignee not recorded'}
                          </span>
                        </td>
                        <td>
                          {bill.values.loadingPort ? bill.values.loadingPort : '—'} to{' '}
                          {bill.values.finalDestinationPort ? bill.values.finalDestinationPort : '—'}
                        </td>
                        <td>
                          {bill.values.invoices.length}
                          <span className="block text-xs text-gray-500">
                            {Number.isFinite(total)
                              ? total.toLocaleString(undefined, { maximumFractionDigits: 2 })
                              : '0'}{' '}
                            across items
                          </span>
                        </td>
                        <td>
                          <Badge variant="secondary">Draft</Badge>
                        </td>
                        <td>{Number.isNaN(updatedDate.getTime()) ? '—' : updatedDate.toLocaleDateString()}</td>
                        <td className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              disabled={downloadingId === bill.id}
                              onClick={() => void handleDownloadFlatFile(bill)}>
                              {downloadingId === bill.id ? 'Downloading...' : 'Flat File'}
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => navigate(routes.toShippingBillEdit(bill.id))}>
                              Open
                            </Button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </Table>
            </div>
          )}

          {!loadError && !isLoading && filtered.length === 0 && (
            <div className="rounded-lg border border-dashed border-gray-300 p-10 text-center">
              <p className="font-medium">{search ? 'No matching shipping bills' : 'No shipping bills yet'}</p>
              <p className="mt-1 text-sm text-gray-500">
                {search ? 'Try another job number or party name.' : 'Create a bill to start an export job.'}
              </p>
              {!search && (
                <Button className="mt-4" onClick={() => navigate(routes.shippingBillNew)}>
                  Create shipping bill
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
