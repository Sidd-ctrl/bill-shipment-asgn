import { documentCodes } from '@/data/e-sanchit-codes'
import { quantityCodes } from '@/data/quantity-code'
import schemeCodes from '@/data/scheme-codes'
import { stateOptions } from '@/data/states'
import { Trades } from '@/data/trade-agrements'
import { cargoOptions, contractTypes, paymentTypes, priceInclusionTypes, sealTypes, weightUnits } from '@/data/types'
import { countries, loadingPorts, ports } from './model'

export interface SelectOption {
  value: string | number
  label: string
}

export interface ReferenceData {
  documentCodes: SelectOption[]
  quantityCodes: SelectOption[]
  schemeCodes: typeof schemeCodes
  stateOptions: SelectOption[]
  tradeAgreements: SelectOption[]
  cargoOptions: SelectOption[]
  contractTypes: SelectOption[]
  paymentTypes: SelectOption[]
  priceInclusionTypes: SelectOption[]
  sealTypes: SelectOption[]
  weightUnits: SelectOption[]
  currencyOptions: SelectOption[]
  portOptions: SelectOption[]
  countries: SelectOption[]
}

const currencyCodes = ['USD', 'EUR', 'INR', 'AED', 'GBP', 'SGD']

function delay<T>(value: T, ms = 200): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(value), ms))
}

export const referenceDataService = {
  async getReferenceData(): Promise<ReferenceData> {
    return delay({
      documentCodes,
      quantityCodes,
      schemeCodes,
      stateOptions,
      tradeAgreements: Trades,
      cargoOptions,
      contractTypes,
      paymentTypes,
      priceInclusionTypes,
      sealTypes,
      weightUnits,
      currencyOptions: currencyCodes.map((value) => ({ value, label: value })),
      portOptions: ports.map((port) => ({ value: port.code, label: `${port.name} · ${port.code}` })),
      countries
    })
  },

  async searchDocumentCodes(query: string): Promise<SelectOption[]> {
    const normalizedQuery = query.toLowerCase().trim()
    const filtered = documentCodes.filter(
      (entry) =>
        entry.label.toLowerCase().includes(normalizedQuery) || entry.value.toLowerCase().includes(normalizedQuery)
    )
    return delay(
      filtered.map((entry) => ({ value: entry.value, label: entry.label })),
      120
    )
  },

  async getDocumentCodeLabel(value: string): Promise<string> {
    const found = documentCodes.find((entry) => entry.value === value || entry.label === value)
    return delay(found ? found.label : value, 50)
  },

  async searchFileTypes(query: string): Promise<SelectOption[]> {
    const options = [{ value: 'pdf', label: 'PDF' }]
    const normalizedQuery = query.toLowerCase().trim()
    return delay(
      options.filter(
        (entry) => entry.label.toLowerCase().includes(normalizedQuery) || entry.value.includes(normalizedQuery)
      ),
      120
    )
  },

  async getLoadingPorts() {
    return delay(loadingPorts, 50)
  }
}
