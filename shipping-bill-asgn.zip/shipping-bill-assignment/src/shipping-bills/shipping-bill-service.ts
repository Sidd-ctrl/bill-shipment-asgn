import { getDemoData, saveBill } from './demo-store'
import { SavedBill, ShippingBillFormValues } from './model'

export const SIMULATE_FAILURE_KEY = 'export-software-simulate-service-failure'

const LIST_DELAY_MS = 350
const SAVE_DELAY_MS = 600

function delay<T>(value: T, ms: number): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(value), ms))
}

function shouldSimulateFailure() {
  try {
    if (window.localStorage.getItem(SIMULATE_FAILURE_KEY) === '1') {
      window.localStorage.removeItem(SIMULATE_FAILURE_KEY)
      return true
    }
  } catch {
    return false
  }
  return false
}

export function generateFlatFileContent(bill: SavedBill): string {
  const values = bill.values
  const lines: string[] = []
  const loadingPort = values.loadingPort.trim() !== '' ? values.loadingPort : 'INMUN1'
  const dischargePort = values.dischargePort ?? values.finalDestinationPort
  lines.push(`HREC**ZZ*${loadingPort}*ZZ*ICEGATE*01*SB*1.0*`)
  lines.push(`<TABLE>SHIPPING_BILL`)
  lines.push(
    `<F>MESSAGE_TYPE^CHA_ID^JOB_NO^JOB_DATE^EXPORTER_ID^EXPORTER_BRANCH^CONSIGNEE_ID^LOADING_PORT^DEST_PORT^DISCHARGE_PORT^SEAL_TYPE^NATURE_OF_CARGO^GROSS_WEIGHT^NET_WEIGHT^UOM^PACKAGES^MARKS`
  )
  lines.push(
    `<R>F^1000^${values.jobNumber ?? ''}^${values.jobDate}^${values.exporterId}^${values.exporterBranchId}^${values.consigneeId}^${values.loadingPort}^${values.finalDestinationPort}^${dischargePort}^${values.sealType ?? ''}^${values.natureOfCargo}^${values.grossWeight ?? ''}^${values.netWeight ?? ''}^${values.measurementUnit}^${values.totalPackages ?? ''}^${(values.marksAndNumbers ?? '').replace(/[\^\r\n]+/g, ' ')}`
  )
  if (values.invoices.length > 0) {
    lines.push(`<TABLE>INVOICE`)
    lines.push(`<F>INVOICE_SN^INVOICE_NO^INVOICE_DATE^CURRENCY^CONTRACT_TYPE^BUYER_ID^FREIGHT_AMOUNT^INSURANCE_AMOUNT`)
    values.invoices.forEach((invoice, index) => {
      lines.push(
        `<R>${index + 1}^${invoice.invoiceNumber}^${invoice.invoiceDate}^${invoice.currency}^${invoice.contractType}^${invoice.buyerId}^${invoice.freightAmount ?? 0}^${invoice.insuranceAmount ?? 0}`
      )
    })
    lines.push(`<TABLE>ITEM`)
    lines.push(`<F>INVOICE_SN^ITEM_SN^RITC_CODE^DESCRIPTION^QUANTITY^UOM^UNIT_PRICE^LINE_TOTAL^SCHEME_CODE`)
    values.invoices.forEach((invoice, invoiceIndex) => {
      invoice.items.forEach((item, itemIndex) => {
        const total = (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0)
        lines.push(
          `<R>${invoiceIndex + 1}^${itemIndex + 1}^${item.ritcCode}^${item.goodsDescription1.replace(/[\^\r\n]+/g, ' ')}^${item.quantity}^${item.unitOfMeasurement}^${item.unitPrice}^${total.toFixed(2)}^${item.schemeCode ?? ''}`
        )
      })
    })
  }
  if (values.packingRanges.length > 0) {
    lines.push(`<TABLE>PACKING`)
    lines.push(`<F>FROM_PKG^TO_PKG^PKG_CODE`)
    values.packingRanges.forEach((range) => {
      lines.push(`<R>${range.packingNumberFrom}^${range.packingNumberTo}^${range.packingCode ?? 'CTN'}`)
    })
  }
  lines.push(`TREC**ZZ*${loadingPort}*ZZ*ICEGATE*01*SB*1.0*`)
  return lines.join('\r\n')
}

function triggerBlobDownload(blob: Blob, filename: string) {
  const url = window.URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = filename
  document.body.appendChild(anchor)
  anchor.click()
  anchor.remove()
  setTimeout(() => window.URL.revokeObjectURL(url), 1000)
}

export interface SaveShippingBillResult {
  bill: SavedBill
  reference: string
}

export const shippingBillService = {
  async list(): Promise<SavedBill[]> {
    if (shouldSimulateFailure()) {
      await delay(null, LIST_DELAY_MS)
      throw new Error('The mock service could not load shipping bills. Your saved data has not been changed.')
    }
    return delay([...getDemoData().bills], LIST_DELAY_MS)
  },

  async getById(id: string | number): Promise<SavedBill | undefined> {
    const bill = getDemoData().bills.find((entry) => entry.id === Number(id))
    return delay(bill, 250)
  },

  async getInitialValues(id?: string): Promise<ShippingBillFormValues | undefined> {
    if (!id) return delay(undefined, 250)
    const bill = getDemoData().bills.find((entry) => entry.id === Number(id))
    return delay(bill?.values, 250)
  },

  async save(values: ShippingBillFormValues, id?: number): Promise<SaveShippingBillResult> {
    await delay(null, SAVE_DELAY_MS)
    if (shouldSimulateFailure()) {
      throw new Error(
        'The mock service could not save this shipping bill. Check the details and try again. Nothing was submitted.'
      )
    }
    const bill = saveBill(values, id)
    return { bill, reference: `SB-${bill.id}` }
  },

  async downloadFlatFile(id: string | number, billData?: SavedBill): Promise<{ source: 'local' }> {
    await delay(null, 300)
    const bill = billData ?? getDemoData().bills.find((entry) => entry.id === Number(id))
    if (!bill) throw new Error('Shipping bill not found, so the flat file could not be generated.')
    const content = generateFlatFileContent(bill)
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' })
    triggerBlobDownload(blob, `shipping_bill_${bill.values.jobNumber ?? bill.id}.sb`)
    return { source: 'local' }
  }
}
