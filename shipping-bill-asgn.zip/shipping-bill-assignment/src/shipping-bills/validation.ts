import { ShippingBillFormValues } from './model'

export type FormTab = 'details' | 'invoices' | 'documents'

export interface ValidationIssue {
  path: string
  message: string
  tab: FormTab
}

function isBlank(value?: string) {
  return value == null || value.trim() === ''
}

function toNumber(value?: string) {
  if (isBlank(value)) return undefined
  const parsed = Number(value)
  return Number.isFinite(parsed) ? parsed : undefined
}

function isValidDate(value?: string) {
  if (!value || value.trim() === '') return false
  const date = new Date(value)
  return !Number.isNaN(date.getTime())
}

export function validateShippingBill(values: ShippingBillFormValues): ValidationIssue[] {
  const issues: ValidationIssue[] = []
  function add(path: string, message: string, tab: FormTab) {
    issues.push({ path, message, tab })
  }

  if (isBlank(values.jobDate)) add('jobDate', 'Job date is required', 'details')
  else if (!isValidDate(values.jobDate)) add('jobDate', 'Enter a valid job date', 'details')

  if (isBlank(values.exporterId)) add('exporterId', 'Select an exporter', 'details')
  if (isBlank(values.exporterBranchId)) add('exporterBranchId', 'Select an exporter branch', 'details')
  if (isBlank(values.consigneeId)) add('consigneeId', 'Select a consignee', 'details')
  if (isBlank(values.consigneeBranchId)) add('consigneeBranchId', 'Select a consignee branch', 'details')
  if (isBlank(values.loadingPort)) add('loadingPort', 'Select a port of loading', 'details')
  if (isBlank(values.finalDestinationPort)) add('finalDestinationPort', 'Select a final destination port', 'details')

  if (!isBlank(values.loadingPort) && values.loadingPort === values.finalDestinationPort) {
    add('finalDestinationPort', 'Destination port should differ from the port of loading', 'details')
  }

  const grossWeight = toNumber(values.grossWeight)
  const netWeight = toNumber(values.netWeight)
  if (values.grossWeight && grossWeight == null) add('grossWeight', 'Gross weight must be a number', 'details')
  if (values.netWeight && netWeight == null) add('netWeight', 'Net weight must be a number', 'details')
  if (grossWeight != null && grossWeight < 0) add('grossWeight', 'Gross weight cannot be negative', 'details')
  if (netWeight != null && netWeight < 0) add('netWeight', 'Net weight cannot be negative', 'details')
  if (grossWeight != null && netWeight != null && netWeight > grossWeight) {
    add('netWeight', 'Net weight cannot be greater than gross weight', 'details')
  }

  const totalPackages = toNumber(values.totalPackages)
  if (totalPackages != null && (!Number.isInteger(totalPackages) || totalPackages < 0)) {
    add('totalPackages', 'Total packages must be a whole number of zero or more', 'details')
  }

  if (!isBlank(values.rbiWaiverDate) && !isValidDate(values.rbiWaiverDate)) {
    add('rbiWaiverDate', 'Enter a valid RBI waiver date', 'details')
  }

  if (values.invoices.length === 0) {
    add('invoices', 'Add at least one invoice', 'invoices')
    return issues
  }

  const invoiceNumbers = new Map<string, number>()

  values.invoices.forEach((invoice, invoiceIndex) => {
    const prefix = `invoices.${invoiceIndex}`
    if (isBlank(invoice.invoiceNumber)) add(`${prefix}.invoiceNumber`, 'Invoice number is required', 'invoices')
    if (!isBlank(invoice.invoiceNumber)) {
      const key = invoice.invoiceNumber.trim().toLowerCase()
      if (invoiceNumbers.has(key))
        add(`${prefix}.invoiceNumber`, 'Invoice numbers must be unique on a bill', 'invoices')
      invoiceNumbers.set(key, invoiceIndex)
    }
    if (isBlank(invoice.invoiceDate)) add(`${prefix}.invoiceDate`, 'Invoice date is required', 'invoices')
    else if (!isValidDate(invoice.invoiceDate)) add(`${prefix}.invoiceDate`, 'Enter a valid invoice date', 'invoices')
    else if (isValidDate(values.jobDate) && invoice.invoiceDate > values.jobDate) {
      add(`${prefix}.invoiceDate`, 'Invoice date cannot be after the job date', 'invoices')
    }
    if (isBlank(invoice.currency)) add(`${prefix}.currency`, 'Select a currency', 'invoices')
    if (isBlank(invoice.contractType)) add(`${prefix}.contractType`, 'Select a contract type', 'invoices')

    if (!invoice.buyerSameAsConsignee) {
      if (isBlank(invoice.buyerId))
        add(`${prefix}.buyerId`, 'Select a buyer or mark buyer same as consignee', 'invoices')
      if (isBlank(invoice.buyerBranchId)) add(`${prefix}.buyerBranchId`, 'Select a buyer branch', 'invoices')
    }

    const chargeFields: [string, string | undefined][] = [
      ['freightRate', invoice.freightRate],
      ['freightAmount', invoice.freightAmount],
      ['insuranceRate', invoice.insuranceRate],
      ['insuranceAmount', invoice.insuranceAmount],
      ['commissionRate', invoice.commissionRate],
      ['commissionAmount', invoice.commissionAmount],
      ['discountRate', invoice.discountRate],
      ['discountAmount', invoice.discountAmount]
    ]
    chargeFields.forEach(([field, value]) => {
      const parsed = toNumber(value)
      if (value && parsed == null) add(`${prefix}.${field}`, 'Enter a valid number', 'invoices')
      if (parsed != null && parsed < 0) add(`${prefix}.${field}`, 'Charges cannot be negative', 'invoices')
      if (field.endsWith('Rate') && parsed != null && parsed > 100) {
        add(`${prefix}.${field}`, 'Rate cannot be more than 100%', 'invoices')
      }
    })

    if (invoice.items.length === 0) {
      add(`${prefix}.items`, 'Add at least one item to each invoice', 'invoices')
      return
    }

    invoice.items.forEach((item, itemIndex) => {
      const itemPrefix = `${prefix}.items.${itemIndex}`
      if (isBlank(item.ritcCode)) add(`${itemPrefix}.ritcCode`, 'RITC code is required', 'invoices')
      else if (!/^\d{8}$/.test(item.ritcCode.trim())) {
        add(`${itemPrefix}.ritcCode`, 'RITC code should be 8 digits', 'invoices')
      }
      if (isBlank(item.goodsDescription1))
        add(`${itemPrefix}.goodsDescription1`, 'Goods description is required', 'invoices')

      const quantity = toNumber(item.quantity)
      if (quantity == null) add(`${itemPrefix}.quantity`, 'Enter a quantity above zero', 'invoices')
      else if (quantity <= 0) add(`${itemPrefix}.quantity`, 'Quantity must be above zero', 'invoices')

      const unitPrice = toNumber(item.unitPrice)
      if (unitPrice == null) add(`${itemPrefix}.unitPrice`, 'Enter a unit price above zero', 'invoices')
      else if (unitPrice <= 0) add(`${itemPrefix}.unitPrice`, 'Unit price must be above zero', 'invoices')

      if (isBlank(item.unitOfMeasurement)) add(`${itemPrefix}.unitOfMeasurement`, 'Select a unit', 'invoices')

      if (item.thirdPartyItem) {
        if (isBlank(item.itemThirdPartyId))
          add(`${itemPrefix}.itemThirdPartyId`, 'Select the item third party', 'invoices')
        if (isBlank(item.itemThirdPartyBranchId)) {
          add(`${itemPrefix}.itemThirdPartyBranchId`, 'Select the item third party branch', 'invoices')
        }
      }

      if (item.igstPaymentStatus === 'P') {
        if (toNumber(item.taxableValue) == null)
          add(`${itemPrefix}.taxableValue`, 'Enter the taxable value for IGST payment', 'invoices')
        if (toNumber(item.igstAmount) == null)
          add(`${itemPrefix}.igstAmount`, 'Enter the IGST amount for IGST payment', 'invoices')
      }
    })
  })

  values.containers.forEach((container, index) => {
    if (isBlank(container.containerNumber)) {
      add(`containers.${index}.containerNumber`, 'Container number is required', 'documents')
    } else if (!/^[A-Za-z]{4}\d{7}$/.test(container.containerNumber.trim())) {
      add(
        `containers.${index}.containerNumber`,
        'Use 4 letters followed by 7 digits, for example MSCU1234567',
        'documents'
      )
    }
    if (!isBlank(container.sealDate) && !isValidDate(container.sealDate)) {
      add(`containers.${index}.sealDate`, 'Enter a valid seal date', 'documents')
    }
  })

  values.packingRanges.forEach((range, index) => {
    const from = toNumber(range.packingNumberFrom)
    const to = toNumber(range.packingNumberTo)
    if (from == null) add(`packingRanges.${index}.packingNumberFrom`, 'Enter the first package number', 'documents')
    if (to == null) add(`packingRanges.${index}.packingNumberTo`, 'Enter the last package number', 'documents')
    if (from != null && to != null && to < from) {
      add(`packingRanges.${index}.packingNumberTo`, 'Last package number cannot be before the first', 'documents')
    }
  })

  values.documents.forEach((document, index) => {
    if (isBlank(document.documentTypeCode)) {
      add(`documents.${index}.documentTypeCode`, 'Select a document type', 'documents')
    }
    if (!isBlank(document.documentIssueDate) && !isValidDate(document.documentIssueDate)) {
      add(`documents.${index}.documentIssueDate`, 'Enter a valid issue date', 'documents')
    }
    if (!isBlank(document.documentExpiryDate) && !isValidDate(document.documentExpiryDate)) {
      add(`documents.${index}.documentExpiryDate`, 'Enter a valid expiry date', 'documents')
    }
    if (
      document.documentIssueDate &&
      document.documentExpiryDate &&
      isValidDate(document.documentIssueDate) &&
      isValidDate(document.documentExpiryDate) &&
      document.documentExpiryDate < document.documentIssueDate
    ) {
      add(`documents.${index}.documentExpiryDate`, 'Expiry date cannot be before the issue date', 'documents')
    }
  })

  values.licenses.forEach((license, index) => {
    if (isBlank(license.registrationNumber)) {
      add(`licenses.${index}.registrationNumber`, 'Licence registration number is required', 'documents')
    }
    const quantity = toNumber(license.licenseQuantity)
    const exportQuantity = toNumber(license.licenseExportQuantity)
    if (quantity != null && exportQuantity != null && exportQuantity > quantity) {
      add(`licenses.${index}.licenseExportQuantity`, 'Export quantity cannot exceed licence quantity', 'documents')
    }
  })

  return issues
}

export function firstIssueTab(issues: ValidationIssue[]): FormTab {
  if (issues.some((issue) => issue.tab === 'details')) return 'details'
  if (issues.some((issue) => issue.tab === 'invoices')) return 'invoices'
  return 'documents'
}
