export function SrHockeyStickPuck(props: React.SVGProps<SVGSVGElement>) {
  return <svg viewBox="0 0 24 24" fill="currentColor" {...props}><path d="M23.461.112a1 1 0 0 0-1.349.427l-8.543 16.46H3.5c-1.93 0-3.5 1.57-3.5 3.5s1.57 3.5 3.5 3.5h5.044a5.98 5.98 0 0 0 5.326-3.236L23.888 1.46a1 1 0 0 0-.427-1.348M24 23a1 1 0 0 1-1 1h-4a1 1 0 1 1 0-2h4a1 1 0 0 1 1 1" /></svg>;
}