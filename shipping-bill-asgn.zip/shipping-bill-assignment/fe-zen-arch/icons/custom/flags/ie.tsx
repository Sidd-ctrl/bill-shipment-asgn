export function Ie(props: React.SVGProps<SVGSVGElement>) {
  return <svg viewBox="0 0 6 3" fill="currentColor" {...props}><path fill="#009A44" d="M0 0h6v3H0z" /><path fill="#fff" d="M2 0h4v3H2z" /><path fill="#FF8200" d="M4 0h2v3H4z" /></svg>;
}