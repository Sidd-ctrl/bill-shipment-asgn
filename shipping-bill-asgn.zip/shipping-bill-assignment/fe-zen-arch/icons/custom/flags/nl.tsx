export function Nl(props: React.SVGProps<SVGSVGElement>) {
  return <svg viewBox="0 0 9 6" fill="currentColor" {...props}><path fill="#21468B" d="M0 0h9v6H0z" /><path fill="#FFF" d="M0 0h9v4H0z" /><path fill="#AE1C28" d="M0 0h9v2H0z" /></svg>;
}