# Export Software Frontend — Shipping Bill Assignment

## Project overview

A React + TypeScript frontend for creating and managing Indian export Shipping Bills, built on the `fe-zen-arch` shared architecture (included as the `fe-zen-arch` Git submodule). Exporters, consignees, invoices, items, containers, packing ranges, supporting documents and licences are captured in a three-tab form (Details, Invoices & goods, Others) and persisted through an asynchronous mock service layer backed by browser local storage. The dashboard lists saved bills, supports search, and generates a downloadable ICEGATE-style flat file (`.sb`) per bill.

There is no backend in this assignment. All data access goes through Promise-based mock services with simulated latency, so the UI, loading states and error handling behave as they would against a real HTTP API.

## Prerequisites

- Node.js 20 or later
- pnpm 10 (via Corepack: `corepack enable` then `corepack prepare pnpm@10.15.0 --activate`, or any pnpm 10 installation)
- Git with access to `https://github.com/shivamkj/fe-zen-arch.git` (the submodule). If you received this project as a ZIP, the submodule contents are already included and no Git access is needed to run it.

No API keys or manual credentials are required.

## Installation and startup

If you cloned the repository instead of using the ZIP, initialise the submodule first:

```bash
git submodule update --init
```

If your Git cannot use the SSH submodule URL, run this once before the submodule command:

```bash
git config url."https://github.com/".insteadOf "git@github.com:"
```

Then:

```bash
pnpm install
pnpm dev
```

The dev server runs on port 5173. Open `http://localhost:5173/`.

## Available scripts

| Command          | Purpose                                                              |
| ---------------- | -------------------------------------------------------------------- |
| `pnpm dev`       | Start the Vite dev server on port 5173                               |
| `pnpm build`     | Production build into `dist/`                                        |
| `pnpm preview`   | Serve the production build                                           |
| `pnpm lint`      | fe-zen-arch lint pipeline (Prettier, tsc, ESLint) with auto-fix      |
| `pnpm lint-check`| Same pipeline without auto-fix                                       |

## Folder structure

```text
src/
  dashboard/
    list-dashboard.tsx          Shipping bill list, search, flat-file download
  data/                         Static reference datasets (codes and option lists)
  shared/
    application-layout.tsx      Page shell
    interceptors.ts             Request interceptors for the fe-zen-arch HTTP client
    route-paths.ts              Route path definitions
    routes.tsx                  Route table
  shipping-bills/
    shipping-bill-form.tsx      Shipping Bill form (tabs, sections, party pickers)
    model.ts                    Form value types, defaults, totals, API payload mapping
    validation.ts               Cross-field and format validation rules
    shipping-bill-service.ts    Async mock service for bills (list, get, save, flat file)
    party-mock-service.ts       Async mock search for exporters, branches, consignees, ports, marks
    reference-data-service.ts   Async access to dropdown and code-list reference data
    demo-store.ts               Local-storage-backed demo data store and seed data
    party-dialogs.tsx           Quick-add dialogs for parties and branches
    workflow.ts                 Workflow step definitions shown above the form
fe-zen-arch/                    Shared architecture submodule (core, ui, icons packages)
```

## Architecture

- UI components (`shipping-bill-form.tsx`, `party-dialogs.tsx`, `list-dashboard.tsx`) render the form and dashboard. They own presentation and local UI state only (active tab, dialogs, search text).
- Form state is managed by React Hook Form through the fe-zen-arch `core/form` wrapper (`useForm`, `Form`). Nested lists (invoices, items, containers, packing ranges, documents, licences) use `useFieldArray`. All tabs stay mounted so the whole bill is validated on submit.
- Validation lives outside the components in `validation.ts` (cross-field and format rules, mapped to the tab that owns each field) alongside the leaf-field schema in the form module. Validation messages are shown at field level with a summary error and automatic navigation to the tab containing the first problem.
- Mock services (`shipping-bill-service.ts`, `party-mock-service.ts`, `reference-data-service.ts`) are the only way components load or save data. Services return Promises with a small simulated delay. `demo-store.ts` is the in-memory/local-storage data source behind the bill and party services; `src/data/` holds static code lists behind the reference-data service.
- The save path is guarded against duplicate submission (a synchronous in-flight flag plus the framework's submitting state), disables controls while saving, keeps the user's input untouched when a save fails, and shows a success confirmation with the saved reference (`SB-<id>`) plus links to the list and to a new bill.

## Mock services and replacing them with HTTP APIs

`shippingBillService` exposes `list()`, `getById(id)`, `getInitialValues(id)`, `save(values, id?)` and `downloadFlatFile(id, bill?)`. `partyMockService` exposes search and lookup functions for exporters, consignees, branches and ports, plus `getMarksAndNumbersOptions`. `referenceDataService.getReferenceData()` returns every dropdown/code list the form needs, and `searchDocumentCodes` / `searchFileTypes` back the document pickers.

To use a real backend later, replace the body of each service function with an HTTP call (the fe-zen-arch `core/request` client is already wired with interceptors in `src/index.tsx`) and keep the same function signatures and return types. The payload shape for a future `POST /api/shipping-bills` is already defined by `toShippingBillPayload` in `model.ts`. No component changes should be needed.

Simulated failure: to exercise error handling, run this in the browser console and then save a bill or refresh the dashboard. The next service call fails once with a readable error; no data is written.

```js
localStorage.setItem('export-software-simulate-service-failure', '1')
```

## Domain assumptions

- A Shipping Bill belongs to one exporter (with a branch/address) and one consignee (with a branch/address), ships from an Indian port of loading to a foreign final destination port, and contains one or more invoices, each with one or more goods items.
- Countries are derived from port codes when the payload is built, as in the starter code.
- An invoice's buyer defaults to the consignee unless "buyer same as consignee" is unchecked, in which case a buyer and branch are required. Third-party involvement is optional per invoice and per item.
- These are sensible product assumptions for this assignment, not exhaustive Indian customs rules. Specifically: RITC codes are expected to be 8 digits; net weight must not exceed gross weight; an invoice date must not be after the job date; invoice numbers must be unique within a bill; container numbers, when entered, should follow the common 4-letters-plus-7-digits pattern; charge rates must be between 0 and 100%; licence export quantity must not exceed licence quantity; document expiry must not precede issue. No claim is made that these are legally complete customs validations.

## Validation and testing performed

Verified on 20 October 2026 in a Linux sandbox with Node 20.20.2 and pnpm 10.15.0:

- `pnpm install` — succeeds.
- `pnpm build` — succeeds (Vite production build). Note: the starter `postcss.config.js` re-exported the fe-zen-arch config, whose production-only `cssnano`/`postcss-variable-compress` plugins currently fail to load with the pinned dependency set (`trustedFunctions.difference is not a function`). The root `postcss.config.js` now keeps only the Tailwind PostCSS plugin, which fixes the production build without new dependencies.
- `tsc --incremental false` — passes with no errors. The starter had two pre-existing type errors in the shipping bill form (a `clsx` call and an `InputError` generic); both are fixed.
- ESLint over `src/` — errors reduced from 162 (starter) to 5, all pre-existing in `model.ts`/`demo-store.ts` helper code unrelated to this refactor. The remaining output is mostly cspell warnings for domain vocabulary in the static data files.
- There is no test framework in the starter repository and none was added (the assignment forbids new dependencies).
- Browser verification with Playwright/Chromium against the production build: dashboard loads bills asynchronously and shows the seeded bill; invalid Details tab blocks progression with field errors; a complete bill (exporter, branch, consignee, branch, ports, invoice, item) can be created; editing the seeded bill with decimal weights/prices saves and shows the success confirmation with working actions; with the simulated-failure flag set, saving shows an error banner and preserves all input; the mobile viewport shows the framework's pre-existing "Desktop Only" notice (see Limitations).

One bug found by browser testing and fixed: the starter form relied on native browser validation, which blocked saving bills with decimal weights/prices (number inputs in hidden tabs failed step validation and were not focusable). The form now sets `noValidate` on the form element and relies on the schema plus `validation.ts` rules instead.

## Known limitations

- Data persists only in the browser's local storage (`export-software-shipping-bills-v2`); clearing storage resets to the seed data.
- The mock services simulate a single failure via a local-storage flag; there is no offline queue or retry queue.
- Small screens show the fe-zen-arch `SmallScreenWarning` ("Desktop Only — Continue Anyway"). This is starter framework behaviour, left unchanged; the layout itself uses responsive grids and was checked at desktop and mobile widths.
- `pnpm lint` runs the fe-zen-arch pipeline including Prettier over the whole repo (including the submodule); run `pnpm lint-check` for a read-only check. Five pre-existing ESLint errors remain in untouched starter helpers (see above).
- Auth and the HTTP request layer from fe-zen-arch are present and wired, but unused because this assignment has no backend.

## AI Usage & Approach

AI assistance (an AI coding agent in Arena.ai Agent Mode, with file, shell and browser tools) was used to inspect the starter repository, design the service and validation split, refactor the form and dashboard to load and save only through the mock services, fix the production PostCSS configuration and the native-validation save bug, and draft this README. Every change was reviewed against the original source before being kept, and the result was verified by actually running `pnpm install`, `pnpm build`, `tsc`, ESLint, and a Playwright/Chromium walkthrough of the dashboard, validation, successful save, simulated failure and mobile viewport (see "Validation and testing performed" for exact results, including the checks that do not fully pass). No test or check results are claimed that were not executed.
